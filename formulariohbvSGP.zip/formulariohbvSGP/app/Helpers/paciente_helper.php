<?php

if (!function_exists('calcularEdad')) {
    function calcularEdad($fechaNacimiento)
    {
        $fechaNac = new DateTime($fechaNacimiento);
        $hoy = new DateTime();
        $edad = $hoy->diff($fechaNac);
        return $edad->y;
    }
}

if (!function_exists('formatoFecha')) {
    function formatoFecha($fecha, $formato = 'd/m/Y')
    {
        if (empty($fecha)) return '';
        return date($formato, strtotime($fecha));
    }
}