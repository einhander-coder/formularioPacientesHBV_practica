<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Pacientes</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- DataTables CSS (para tablas avanzadas) -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <style>
        .card {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(13, 110, 253, 0.05);
        }
        .badge-estado {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.85em;
        }
        .btn-action {
            width: 35px;
            height: 35px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin: 2px;
        }
        .paciente-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            background-color: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: #6c757d;
        }
        .search-box {
            max-width: 300px;
        }
        .stats-card {
            border-left: 4px solid #0d6efd;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="<?= site_url('/') ?>">
                <i class="bi bi-heart-pulse me-2"></i>Sistema de Pacientes
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?= site_url('pacientes') ?>">
                            <i class="bi bi-list-ul"></i> Lista de Pacientes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('pacientes/crear') ?>">
                            <i class="bi bi-person-plus"></i> Nuevo Paciente
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('informes') ?>">
                            <i class="bi bi-bar-chart"></i> Informes
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- Mensajes -->
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?= session('success') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif ?>

        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?= session('error') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif ?>

        <!-- Estadísticas -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stats-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted">Total Pacientes</h6>
                                <h3><?= $totalPacientes ?></h3>
                            </div>
                            <div class="align-self-center">
                                <i class="bi bi-people-fill fs-1 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stats-card" style="border-left-color: #20c997;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted">Hombres</h6>
                                <h3><?= $hombres ?></h3>
                            </div>
                            <div class="align-self-center">
                                <i class="bi bi-gender-male fs-1 text-success"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stats-card" style="border-left-color: #fd7e14;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted">Mujeres</h6>
                                <h3><?= $mujeres ?></h3>
                            </div>
                            <div class="align-self-center">
                                <i class="bi bi-gender-female fs-1 text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stats-card" style="border-left-color: #6f42c1;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted">Registros Hoy</h6>
                                <h3><?= $registrosHoy ?></h3>
                            </div>
                            <div class="align-self-center">
                                <i class="bi bi-calendar-day fs-1 text-purple"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card Principal -->
        <div class="card">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h4 class="mb-0">
                    <i class="bi bi-list-ul me-2"></i>Listado de Pacientes
                </h4>
                <div>
                    <a href="<?= site_url('pacientes/crear') ?>" class="btn btn-light btn-sm">
                        <i class="bi bi-person-plus"></i> Nuevo Paciente
                    </a>
                </div>
            </div>
            
            <div class="card-body">
                <!-- Filtros -->
                <div class="row mb-4">
                    <div class="col-md-8">
                        <form method="GET" action="<?= site_url('pacientes') ?>" class="row g-2">
                            <div class="col-md-4">
                                <input type="text" 
                                       class="form-control" 
                                       name="search" 
                                       placeholder="Buscar por nombre..."
                                       value="<?= $search ?? '' ?>">
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" name="genero">
                                    <option value="">Todos los géneros</option>
                                    <option value="Masculino" <?= ($generoFilter ?? '') == 'Masculino' ? 'selected' : '' ?>>Masculino</option>
                                    <option value="Femenino" <?= ($generoFilter ?? '') == 'Femenino' ? 'selected' : '' ?>>Femenino</option>
                                    <option value="Otro" <?= ($generoFilter ?? '') == 'Otro' ? 'selected' : '' ?>>Otro</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <input type="date" 
                                       class="form-control" 
                                       name="fecha_registro"
                                       value="<?= $fechaFilter ?? '' ?>">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i> Filtrar
                                </button>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-4 text-end">
                        <div class="btn-group">
                            <a href="<?= site_url('pacientes/exportar/pdf') ?>" class="btn btn-outline-danger btn-sm">
                                <i class="bi bi-file-pdf"></i> PDF
                            </a>
                            <a href="<?= site_url('pacientes/exportar/excel') ?>" class="btn btn-outline-success btn-sm">
                                <i class="bi bi-file-excel"></i> Excel
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Tabla de Pacientes -->
                <div class="table-responsive">
                    <table class="table table-hover table-striped" id="tabla-pacientes">
                        <thead class="table-light">
                            <tr>
                                <th width="50">ID</th>
                                <th>Paciente</th>
                                <th>Información</th>
                                <th>Contacto</th>
                                <th>Fecha Registro</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($pacientes)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <i class="bi bi-people display-6 text-muted d-block mb-2"></i>
                                        <h5>No hay pacientes registrados</h5>
                                        <p class="text-muted">Comienza agregando tu primer paciente</p>
                                        <a href="<?= site_url('pacientes/crear') ?>" class="btn btn-primary">
                                            <i class="bi bi-person-plus"></i> Agregar Primer Paciente
                                        </a>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach($pacientes as $paciente): ?>
                                    <tr>
                                        <td>
                                            <span class="badge bg-secondary">#<?= str_pad($paciente['id'], 4, '0', STR_PAD_LEFT) ?></span>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="paciente-img me-3">
                                                    <?= strtoupper(substr($paciente['nombre'], 0, 1) . substr($paciente['apellido'], 0, 1)) ?>
                                                </div>
                                                <div>
                                                    <strong><?= $paciente['nombre'] ?> <?= $paciente['apellido'] ?></strong>
                                                    <div class="text-muted small">
                                                        <?= $paciente['tipo_documento'] ?? 'DNI' ?>: <?= $paciente['numero_documento'] ?? 'No especificado' ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="small">
                                                <div><i class="bi bi-calendar"></i> <?= date('d/m/Y', strtotime($paciente['fecha_nacimiento'])) ?></div>
                                                <div>
                                                    <span class="badge 
                                                        <?= $paciente['genero'] == 'Masculino' ? 'bg-primary' : 
                                                           ($paciente['genero'] == 'Femenino' ? 'bg-pink' : 'bg-secondary') ?>">
                                                        <?= $paciente['genero'] ?>
                                                    </span>
                                                    <?php if($paciente['tipo_sangre']): ?>
                                                        <span class="badge bg-danger"><?= $paciente['tipo_sangre'] ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="small">
                                                <div><i class="bi bi-telephone"></i> <?= $paciente['telefono'] ?></div>
                                                <?php if($paciente['email']): ?>
                                                    <div><i class="bi bi-envelope"></i> <?= $paciente['email'] ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="small">
                                                <div><?= date('d/m/Y', strtotime($paciente['fecha_registro'])) ?></div>
                                                <div class="text-muted"><?= date('H:i', strtotime($paciente['fecha_registro'])) ?></div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?= site_url('pacientes/ver/' . $paciente['id']) ?>" 
                                                   class="btn btn-info btn-action" 
                                                   title="Ver Detalles">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <a href="<?= site_url('pacientes/editar/' . $paciente['id']) ?>" 
                                                   class="btn btn-warning btn-action" 
                                                   title="Editar">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <button type="button" 
                                                        class="btn btn-danger btn-action btn-eliminar" 
                                                        data-id="<?= $paciente['id'] ?>"
                                                        data-nombre="<?= $paciente['nombre'] ?> <?= $paciente['apellido'] ?>"
                                                        title="Eliminar">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginación -->
                <?php if(isset($pager) && $pager->getPageCount() > 1): ?>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <div class="text-muted">
                            Mostrando <?= $pager->getCurrentPage() * $pager->getPerPage() - $pager->getPerPage() + 1 ?> 
                            a <?= min($pager->getCurrentPage() * $pager->getPerPage(), $totalPacientes) ?> 
                            de <?= $totalPacientes ?> registros
                        </div>
                        <nav>
                            <?= $pager->links() ?>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmación para Eliminar -->
    <div class="modal fade" id="modalEliminar" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">
                        <i class="bi bi-exclamation-triangle"></i> Confirmar Eliminación
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>¿Está seguro que desea eliminar al paciente <strong id="nombre-paciente-eliminar"></strong>?</p>
                    <p class="text-danger small">
                        <i class="bi bi-info-circle"></i> Esta acción no se puede deshacer y se perderán todos los datos del paciente.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <form id="form-eliminar" method="POST" action="">
                        <?= csrf_field() ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-danger">Eliminar Paciente</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        // Inicializar DataTable
        $(document).ready(function() {
            $('#tabla-pacientes').DataTable({
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'
                },
                pageLength: 10,
                ordering: true,
                order: [[0, 'desc']],
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rt<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>'
            });
        });

        // Eliminar paciente
        document.querySelectorAll('.btn-eliminar').forEach(button => {
            button.addEventListener('click', function() {
                const pacienteId = this.getAttribute('data-id');
                const pacienteNombre = this.getAttribute('data-nombre');
                
                document.getElementById('nombre-paciente-eliminar').textContent = pacienteNombre;
                document.getElementById('form-eliminar').action = '<?= site_url("pacientes/eliminar/") ?>' + pacienteId;
                
                const modal = new bootstrap.Modal(document.getElementById('modalEliminar'));
                modal.show();
            });
        });

        // Auto-ocultar alertas después de 5 segundos
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                bootstrap.Alert.getOrCreateInstance(alert).close();
            });
        }, 5000);
    </script>
</body>
</html>