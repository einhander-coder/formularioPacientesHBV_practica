<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Paciente</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .card {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .required::after {
            content: " *";
            color: red;
        }
        .form-section {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
        }
        .section-title {
            color: #2c3e50;
            border-bottom: 2px solid #0d6efd;
            padding-bottom: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="bi bi-heart-pulse me-2"></i>Sistema de Gestion de Pacientes | SGP
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('pacientes') ?>">
                            <i class="bi bi-list-ul"></i> Lista de Pacientes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?= site_url('pacientes/crear') ?>">
                            <i class="bi bi-person-plus"></i> Nuevo Paciente
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <!-- Mensajes de validación -->
                <?php if(session()->has('errors')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <h5><i class="bi bi-exclamation-triangle"></i> Por favor corrige los siguientes errores:</h5>
                        <ul class="mb-0">
                            <?php foreach(session('errors') as $error): ?>
                                <li><?= $error ?></li>
                            <?php endforeach ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif ?>

                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle"></i> <?= session('success') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif ?>

                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">
                            <i class="bi bi-person-plus-fill me-2"></i>Formulario de Registro de Paciente
                        </h4>
                    </div>
                    
                    <div class="card-body">
                        <form action="<?= site_url('pacientes/guardar') ?>" method="POST" id="form-paciente">
                            <!-- Información Personal -->
                            <div class="form-section">
                                <h5 class="section-title">
                                    <i class="bi bi-person-badge"></i> Información Personal
                                </h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="nombre" class="form-label required">Nombre(s)</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="nombre" 
                                               name="nombre" 
                                               value="<?= old('nombre') ?>"
                                               required>
                                        <div class="form-text">Ingrese el nombre completo del paciente</div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="apellido" class="form-label required">Apellido(s)</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="apellido" 
                                               name="apellido"
                                               value="<?= old('apellido') ?>"
                                               required>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="fecha_nacimiento" class="form-label required">Fecha de Nacimiento</label>
                                        <input type="date" 
                                               class="form-control" 
                                               id="fecha_nacimiento" 
                                               name="fecha_nacimiento"
                                               value="<?= old('fecha_nacimiento') ?>"
                                               required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label required">Género</label>
                                        <div class="d-flex gap-4">
                                            <div class="form-check">
                                                <input class="form-check-input" 
                                                       type="radio" 
                                                       name="genero" 
                                                       id="masculino" 
                                                       value="Masculino"
                                                       <?= old('genero') == 'Masculino' ? 'checked' : '' ?>
                                                       required>
                                                <label class="form-check-label" for="masculino">
                                                    Masculino
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" 
                                                       type="radio" 
                                                       name="genero" 
                                                       id="femenino" 
                                                       value="Femenino"
                                                       <?= old('genero') == 'Femenino' ? 'checked' : '' ?>
                                                       required>
                                                <label class="form-check-label" for="femenino">
                                                    Femenino
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" 
                                                       type="radio" 
                                                       name="genero" 
                                                       id="otro" 
                                                       value="Otro"
                                                       <?= old('genero') == 'Otro' ? 'checked' : '' ?>
                                                       required>
                                                <label class="form-check-label" for="otro">
                                                    Otro
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="tipo_documento" class="form-label">Tipo de Documento</label>
                                        <select class="form-select" id="tipo_documento" name="tipo_documento">
                                            <option value="">Seleccionar...</option>
                                            <option value="DNI" <?= old('tipo_documento') == 'DNI' ? 'selected' : '' ?>>DNI</option>
                                            <option value="Pasaporte" <?= old('tipo_documento') == 'Pasaporte' ? 'selected' : '' ?>>Pasaporte</option>
                                            <option value="Carnet Extranjería" <?= old('tipo_documento') == 'Carnet Extranjería' ? 'selected' : '' ?>>Carnet Extranjería</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="numero_documento" class="form-label">Número de Documento</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="numero_documento" 
                                               name="numero_documento"
                                               value="<?= old('numero_documento') ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Información de Contacto -->
                            <div class="form-section">
                                <h5 class="section-title">
                                    <i class="bi bi-telephone"></i> Información de Contacto
                                </h5>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="telefono" class="form-label required">Teléfono</label>
                                        <input type="tel" 
                                               class="form-control" 
                                               id="telefono" 
                                               name="telefono"
                                               value="<?= old('telefono') ?>"
                                               required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label">Correo Electrónico</label>
                                        <input type="email" 
                                               class="form-control" 
                                               id="email" 
                                               name="email"
                                               value="<?= old('email') ?>"
                                               placeholder="paciente@ejemplo.com">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="direccion" class="form-label">Dirección</label>
                                    <textarea class="form-control" 
                                              id="direccion" 
                                              name="direccion" 
                                              rows="2"><?= old('direccion') ?></textarea>
                                </div>
                            </div>
                            
                            <!-- Información Médica -->
                            <div class="form-section">
                                <h5 class="section-title">
                                    <i class="bi bi-heart-pulse"></i> Información Médica
                                </h5>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="tipo_sangre" class="form-label">Tipo de Sangre</label>
                                        <select class="form-select" id="tipo_sangre" name="tipo_sangre">
                                            <option value="">Desconocido</option>
                                            <option value="A+" <?= old('tipo_sangre') == 'A+' ? 'selected' : '' ?>>A+</option>
                                            <option value="A-" <?= old('tipo_sangre') == 'A-' ? 'selected' : '' ?>>A-</option>
                                            <option value="B+" <?= old('tipo_sangre') == 'B+' ? 'selected' : '' ?>>B+</option>
                                            <option value="B-" <?= old('tipo_sangre') == 'B-' ? 'selected' : '' ?>>B-</option>
                                            <option value="AB+" <?= old('tipo_sangre') == 'AB+' ? 'selected' : '' ?>>AB+</option>
                                            <option value="AB-" <?= old('tipo_sangre') == 'AB-' ? 'selected' : '' ?>>AB-</option>
                                            <option value="O+" <?= old('tipo_sangre') == 'O+' ? 'selected' : '' ?>>O+</option>
                                            <option value="O-" <?= old('tipo_sangre') == 'O-' ? 'selected' : '' ?>>O-</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="alergias" class="form-label">Alergias Conocidas</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="alergias" 
                                               name="alergias"
                                               value="<?= old('alergias') ?>"
                                               placeholder="Ej: Penicilina, polen, etc.">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="historial_medico" class="form-label">Historial Médico</label>
                                    <textarea class="form-control" 
                                              id="historial_medico" 
                                              name="historial_medico" 
                                              rows="4"
                                              placeholder="Enfermedades previas, cirugías, condiciones crónicas..."><?= old('historial_medico') ?></textarea>
                                    <div class="form-text">Información relevante para el historial médico</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="medicamentos" class="form-label">Medicamentos Actuales</label>
                                    <textarea class="form-control" 
                                              id="medicamentos" 
                                              name="medicamentos" 
                                              rows="3"
                                              placeholder="Medicamentos que toma actualmente..."><?= old('medicamentos') ?></textarea>
                                </div>
                            </div>
                            
                            <!-- Contacto de Emergencia -->
                            <div class="form-section">
                                <h5 class="section-title">
                                    <i class="bi bi-exclamation-triangle"></i> Contacto de Emergencia
                                </h5>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="contacto_emergencia_nombre" class="form-label">Nombre del Contacto</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="contacto_emergencia_nombre" 
                                               name="contacto_emergencia_nombre"
                                               value="<?= old('contacto_emergencia_nombre') ?>">
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="contacto_emergencia_telefono" class="form-label">Teléfono de Emergencia</label>
                                        <input type="tel" 
                                               class="form-control" 
                                               id="contacto_emergencia_telefono" 
                                               name="contacto_emergencia_telefono"
                                               value="<?= old('contacto_emergencia_telefono') ?>">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="contacto_emergencia_parentesco" class="form-label">Parentesco</label>
                                    <select class="form-select" id="contacto_emergencia_parentesco" name="contacto_emergencia_parentesco">
                                        <option value="">Seleccionar...</option>
                                        <option value="Padre" <?= old('contacto_emergencia_parentesco') == 'Padre' ? 'selected' : '' ?>>Padre</option>
                                        <option value="Madre" <?= old('contacto_emergencia_parentesco') == 'Madre' ? 'selected' : '' ?>>Madre</option>
                                        <option value="Hijo/a" <?= old('contacto_emergencia_parentesco') == 'Hijo/a' ? 'selected' : '' ?>>Hijo/a</option>
                                        <option value="Cónyuge" <?= old('contacto_emergencia_parentesco') == 'Cónyuge' ? 'selected' : '' ?>>Cónyuge</option>
                                        <option value="Hermano/a" <?= old('contacto_emergencia_parentesco') == 'Hermano/a' ? 'selected' : '' ?>>Hermano/a</option>
                                        <option value="Otro" <?= old('contacto_emergencia_parentesco') == 'Otro' ? 'selected' : '' ?>>Otro</option>
                                    </select>
                                </div>
                            </div>
                            
                            <!-- Botones -->
                            <div class="d-flex justify-content-between mt-4">
                                <a href="<?= site_url('pacientes') ?>" class="btn btn-secondary">
                                    <i class="bi bi-arrow-left"></i> Volver al Listado
                                </a>
                                
                                <div>
                                    <button type="reset" class="btn btn-outline-danger me-2">
                                        <i class="bi bi-x-circle"></i> Limpiar Formulario
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Guardar Paciente
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    
                    <div class="card-footer text-muted small">
                        <i class="bi bi-info-circle"></i> Los campos marcados con <span class="required"></span> son obligatorios.
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Validación simple del formulario
        document.getElementById('form-paciente').addEventListener('submit', function(e) {
            let telefono = document.getElementById('telefono').value;
            let email = document.getElementById('email').value;
            
            // Validar formato de teléfono (solo números)
            if (telefono && !/^[0-9\s\-\+\(\)]+$/.test(telefono)) {
                alert('Por favor ingrese un número de teléfono válido');
                e.preventDefault();
                return false;
            }
            
            // Validar email si se ingresó
            if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                alert('Por favor ingrese un correo electrónico válido');
                e.preventDefault();
                return false;
            }
            
            // Validar fecha de nacimiento (no puede ser futura)
            let fechaNacimiento = document.getElementById('fecha_nacimiento').value;
            let hoy = new Date().toISOString().split('T')[0];
            if (fechaNacimiento > hoy) {
                alert('La fecha de nacimiento no puede ser futura');
                e.preventDefault();
                return false;
            }
            
            return true;
        });
        
        // Calcular edad automáticamente (opcional)
        document.getElementById('fecha_nacimiento').addEventListener('change', function() {
            const fechaNac = new Date(this.value);
            const hoy = new Date();
            let edad = hoy.getFullYear() - fechaNac.getFullYear();
            const mes = hoy.getMonth() - fechaNac.getMonth();
            
            if (mes < 0 || (mes === 0 && hoy.getDate() < fechaNac.getDate())) {
                edad--;
            }
            
            // Puedes mostrar la edad en un elemento si lo deseas
            // document.getElementById('edad').textContent = edad + ' años';
        });
    </script>
</body>
</html>