<?= $this->extend('layouts/header') ?>

<?= $this->section('styles') ?>
<style>
    .patient-card {
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        border: none;
    }
    .patient-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 40px 30px;
        position: relative;
    }
    .patient-avatar {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: rgba(255,255,255,0.2);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 48px;
        font-weight: bold;
        border: 4px solid white;
        margin: 0 auto 20px;
    }
    .info-card {
        border-left: 4px solid #0d6efd;
        padding: 20px;
        margin-bottom: 20px;
        background: #f8f9fa;
        border-radius: 8px;
    }
    .info-label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 5px;
    }
    .info-value {
        color: #212529;
        font-size: 1.1rem;
    }
    .section-title {
        color: #2c3e50;
        border-bottom: 2px solid #dee2e6;
        padding-bottom: 10px;
        margin-bottom: 20px;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<main class="container py-4">
    <!-- Botón volver -->
    <div class="mb-4">
        <a href="<?= site_url('pacientes') ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Volver al listado
        </a>
    </div>
    
    <!-- Card principal del paciente -->
    <div class="card patient-card mb-5">
        <div class="patient-header text-center">
            <div class="patient-avatar">
                <?= strtoupper(substr($paciente['nombre'], 0, 1) . substr($paciente['apellido'], 0, 1)) ?>
            </div>
            <h1 class="display-6 fw-bold mb-2"><?= esc($paciente['nombre'] . ' ' . $paciente['apellido']) ?></h1>
            <div class="d-flex justify-content-center gap-3">
                <span class="badge bg-light text-dark fs-6">
                    <i class="bi bi-person-badge me-1"></i>
                    <?= $paciente['tipo_documento'] ?? 'DNI' ?>: <?= esc($paciente['numero_documento'] ?? 'N/A') ?>
                </span>
                <span class="badge bg-info fs-6">
                    ID: #<?= str_pad($paciente['id'], 4, '0', STR_PAD_LEFT) ?>
                </span>
            </div>
        </div>
        
        <div class="card-body p-4">
            <div class="row">
                <!-- Columna 1: Información Personal -->
                <div class="col-md-6">
                    <h3 class="section-title">
                        <i class="bi bi-person-circle me-2"></i>Información Personal
                    </h3>
                    
                    <div class="info-card">
                        <div class="row">
                            <div class="col-6 mb-3">
                                <div class="info-label">Fecha de Nacimiento</div>
                                <div class="info-value">
                                    <?= date('d/m/Y', strtotime($paciente['fecha_nacimiento'])) ?>
                                    <span class="badge bg-primary ms-2">
                                        <?= \App\Helpers\paciente_helper::calcularEdad($paciente['fecha_nacimiento']) ?> años
                                    </span>
                                </div>
                            </div>
                            <div class="col-6 mb-3">
                                <div class="info-label">Género</div>
                                <div class="info-value">
                                    <span class="badge <?= $paciente['genero'] == 'Masculino' ? 'bg-primary' : 'bg-pink' ?>">
                                        <?= $paciente['genero'] ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                        <?php if(!empty($paciente['tipo_sangre']) && $paciente['tipo_sangre'] != 'Desconocido'): ?>
                        <div class="mb-3">
                            <div class="info-label">Tipo de Sangre</div>
                            <div class="info-value">
                                <span class="badge bg-danger">
                                    <i class="bi bi-droplet me-1"></i><?= $paciente['tipo_sangre'] ?>
                                </span>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Información de Contacto -->
                    <h3 class="section-title mt-4">
                        <i class="bi bi-telephone me-2"></i>Información de Contacto
                    </h3>
                    
                    <div class="info-card">
                        <div class="mb-3">
                            <div class="info-label">Teléfono</div>
                            <div class="info-value">
                                <i class="bi bi-telephone-fill me-2 text-primary"></i>
                                <?= esc($paciente['telefono']) ?>
                            </div>
                        </div>
                        
                        <?php if(!empty($paciente['email'])): ?>
                        <div class="mb-3">
                            <div class="info-label">Correo Electrónico</div>
                            <div class="info-value">
                                <i class="bi bi-envelope-fill me-2 text-primary"></i>
                                <?= esc($paciente['email']) ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if(!empty($paciente['direccion'])): ?>
                        <div class="mb-3">
                            <div class="info-label">Dirección</div>
                            <div class="info-value">
                                <i class="bi bi-geo-alt-fill me-2 text-primary"></i>
                                <?= esc($paciente['direccion']) ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Columna 2: Información Médica -->
                <div class="col-md-6">
                    <h3 class="section-title">
                        <i class="bi bi-heart-pulse me-2"></i>Información Médica
                    </h3>
                    
                    <div class="info-card">
                        <?php if(!empty($paciente['alergias'])): ?>
                        <div class="mb-3">
                            <div class="info-label">Alergias Conocidas</div>
                            <div class="info-value">
                                <span class="badge bg-warning text-dark">
                                    <i class="bi bi-exclamation-triangle me-1"></i>
                                    <?= esc($paciente['alergias']) ?>
                                </span>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if(!empty($paciente['historial_medico'])): ?>
                        <div class="mb-3">
                            <div class="info-label">Historial Médico</div>
                            <div class="info-value">
                                <?= nl2br(esc($paciente['historial_medico'])) ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if(!empty($paciente['medicamentos'])): ?>
                        <div class="mb-3">
                            <div class="info-label">Medicamentos Actuales</div>
                            <div class="info-value">
                                <?= nl2br(esc($paciente['medicamentos'])) ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Contacto de Emergencia -->
                    <h3 class="section-title mt-4">
                        <i class="bi bi-exclamation-triangle me-2"></i>Contacto de Emergencia
                    </h3>
                    
                    <div class="info-card">
                        <?php if(!empty($paciente['contacto_emergencia_nombre'])): ?>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <div class="info-label">Nombre</div>
                                <div class="info-value"><?= esc($paciente['contacto_emergencia_nombre']) ?></div>
                            </div>
                            <div class="col-6 mb-3">
                                <div class="info-label">Parentesco</div>
                                <div class="info-value"><?= esc($paciente['contacto_emergencia_parentesco'] ?? 'No especificado') ?></div>
                            </div>
                        </div>
                        
                        <?php if(!empty($paciente['contacto_emergencia_telefono'])): ?>
                        <div class="mb-3">
                            <div class="info-label">Teléfono de Emergencia</div>
                            <div class="info-value">
                                <i class="bi bi-telephone-fill me-2 text-danger"></i>
                                <?= esc($paciente['contacto_emergencia_telefono']) ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php else: ?>
                        <div class="text-center text-muted py-3">
                            <i class="bi bi-info-circle display-6"></i>
                            <p class="mt-2">No se ha registrado contacto de emergencia</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Información del Sistema -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card border-light">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="bi bi-clock-history me-2"></i>Información del Sistema
                            </h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <small class="text-muted">Fecha de Registro</small>
                                    <div><?= date('d/m/Y H:i', strtotime($paciente['fecha_registro'])) ?></div>
                                </div>
                                <div class="col-md-4">
                                    <small class="text-muted">Última Actualización</small>
                                    <div>
                                        <?= !empty($paciente['updated_at']) 
                                            ? date('d/m/Y H:i', strtotime($paciente['updated_at']))
                                            : 'No actualizado' ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <small class="text-muted">Estado</small>
                                    <div>
                                        <span class="badge bg-success">Activo</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card-footer bg-light d-flex justify-content-between">
            <div>
                <a href="<?= site_url('pacientes') ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Volver
                </a>
            </div>
            <div class="btn-group">
                <a href="<?= site_url('pacientes/editar/' . $paciente['id']) ?>" 
                   class="btn btn-warning">
                    <i class="bi bi-pencil-square me-1"></i> Editar
                </a>
                <button type="button" class="btn btn-danger" id="btnEliminar">
                    <i class="bi bi-trash me-1"></i> Eliminar
                </button>
            </div>
        </div>
    </div>
</main>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Eliminar paciente
        document.getElementById('btnEliminar').addEventListener('click', function() {
            Swal.fire({
                title: '¿Eliminar paciente?',
                html: `¿Está seguro de eliminar permanentemente a <strong><?= esc($paciente['nombre'] . ' ' . $paciente['apellido']) ?></strong>?<br>
                      <span class="text-danger small">Esta acción eliminará todos los datos médicos del paciente.</span>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar',
                confirmButtonColor: '#dc3545',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '<?= site_url("pacientes/eliminar/" . $paciente['id']) ?>';
                }
            });
        });
        
        // Imprimir información
        document.getElementById('btnImprimir')?.addEventListener('click', function() {
            window.print();
        });
    });
</script>
<?= $this->endSection() ?>