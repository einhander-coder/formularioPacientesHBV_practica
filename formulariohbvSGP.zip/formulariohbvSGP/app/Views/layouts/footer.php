        </main>
        
        <!-- Footer -->
        <footer class="mt-auto bg-dark text-white py-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <h5 class="fw-bold">
                            <i class="bi bi-heart-pulse me-2"></i>Sistema de Pacientes
                        </h5>
                        <p class="text-white-50 small">
                            Sistema de gestión médica desarrollado con CodeIgniter 4 y Bootstrap 5.
                        </p>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <h6 class="fw-bold">Enlaces rápidos</h6>
                        <ul class="list-unstyled">
                            <li><a href="<?= site_url('/') ?>" class="text-white-50 text-decoration-none">Inicio</a></li>
                            <li><a href="<?= site_url('pacientes') ?>" class="text-white-50 text-decoration-none">Pacientes</a></li>
                            <li><a href="<?= site_url('informes') ?>" class="text-white-50 text-decoration-none">Informes</a></li>
                            <li><a href="<?= site_url('help') ?>" class="text-white-50 text-decoration-none">Ayuda</a></li>
                        </ul>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <h6 class="fw-bold">Contacto</h6>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="bi bi-envelope me-2"></i>
                                <span class="text-white-50">soporte@sistema-pacientes.com</span>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-telephone me-2"></i>
                                <span class="text-white-50">+51 987 654 321</span>
                            </li>
                            <li>
                                <i class="bi bi-geo-alt me-2"></i>
                                <span class="text-white-50">Lima, Perú</span>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <hr class="bg-secondary my-3">
                
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
                    <div class="mb-2 mb-md-0">
                        <span class="text-white-50 small">
                            &copy; <?= date('Y') ?> Sistema de Pacientes. Todos los derechos reservados.
                        </span>
                    </div>
                    <div class="small">
                        <span class="text-white-50">Versión 1.0.0</span>
                        <span class="mx-2 text-secondary">•</span>
                        <span class="text-white-50">
                            <i class="bi bi-code-slash me-1"></i>Desarrollado con ❤️
                        </span>
                    </div>
                </div>
            </div>
        </footer>
        
        <!-- Scripts -->
        <!-- jQuery -->
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        
        <!-- Bootstrap Bundle con Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        
        <!-- DataTables -->
        <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
        
        <!-- Select2 -->
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        
        <!-- Flatpickr -->
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/es.js"></script>
        
        <!-- Scripts personalizados -->
        <script src="<?= base_url('js/app.js?v=1.0') ?>"></script>
        
        <!-- Scripts específicos por página -->
        <?= $this->renderSection('scripts') ?>
        
        <!-- Inicializaciones generales -->
        <script>
            // Auto-cierre de alerts después de 5 segundos
            setTimeout(() => {
                document.querySelectorAll('.alert').forEach(alert => {
                    new bootstrap.Alert(alert).close();
                });
            }, 5000);
            
            // Inicializar tooltips
            const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
            const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
            
            // Inicializar popovers
            const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]');
            const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl));
        </script>
    </body>
</html>