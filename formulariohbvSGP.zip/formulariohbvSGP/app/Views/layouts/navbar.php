<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm sticky-top">
    <div class="container-fluid">
        <!-- Logo/Brand -->
        <a class="navbar-brand d-flex align-items-center" href="<?= site_url('/') ?>">
            <i class="bi bi-heart-pulse fs-3 me-2"></i>
            <div>
                <span class="fw-bold">Sistema</span>
                <small class="d-block text-white-50" style="font-size: 0.8rem;">Gestión de Pacientes</small>
            </div>
        </a>
        
        <!-- Toggle para móvil -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Menú principal -->
        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= current_url() == site_url('/') ? 'active' : '' ?>" 
                       href="<?= site_url('/') ?>">
                        <i class="bi bi-house-door me-1"></i> Inicio
                    </a>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= strpos(current_url(), 'pacientes') !== false ? 'active' : '' ?>" 
                       href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-people me-1"></i> Pacientes
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="<?= site_url('pacientes') ?>">
                                <i class="bi bi-list-ul me-2"></i> Listar Pacientes
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="<?= site_url('pacientes/crear') ?>">
                                <i class="bi bi-person-add me-2"></i> Nuevo Paciente
                            </a>
                        </li>
                    </ul>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link <?= strpos(current_url(), 'informes') !== false ? 'active' : '' ?>" 
                       href="<?= site_url('informes') ?>">
                        <i class="bi bi-bar-chart me-1"></i> Informes
                    </a>
                </li>
            </ul>
            
            <!-- Búsqueda rápida -->
            <form class="d-flex me-3" action="<?= site_url('pacientes') ?>" method="get">
                <div class="input-group input-group-sm">
                    <input type="text" class="form-control" placeholder="Buscar paciente..." 
                           name="search" value="<?= esc($search ?? '') ?>">
                    <button class="btn btn-outline-light" type="submit">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </form>
            
            <!-- Acciones rápidas -->
            <div class="d-flex">
                <a href="<?= site_url('pacientes/crear') ?>" class="btn btn-light btn-sm me-2">
                    <i class="bi bi-person-plus me-1"></i> Nuevo
                </a>
                <!-- Futuro: Dropdown de usuario -->
            </div>
        </div>
    </div>
</nav>