<?= $this->extend('layouts/header') ?>

<?= $this->section('content') ?>
<main class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <div class="error-icon display-1 text-muted mb-4">
                <i class="bi bi-exclamation-octagon"></i>
            </div>
            <h1 class="display-4 fw-bold text-danger mb-3">404</h1>
            <h2 class="h3 mb-4">Página no encontrada</h2>
            <p class="lead text-muted mb-5">
                Lo sentimos, la página que estás buscando no existe o ha sido movida.
            </p>
            <div class="d-flex justify-content-center gap-3">
                <a href="<?= site_url('/') ?>" class="btn btn-primary btn-lg">
                    <i class="bi bi-house-door me-2"></i>Volver al inicio
                </a>
                <a href="<?= site_url('pacientes') ?>" class="btn btn-outline-primary btn-lg">
                    <i class="bi bi-people me-2"></i>Ver pacientes
                </a>
            </div>
        </div>
    </div>
</main>
<?= $this->endSection() ?>