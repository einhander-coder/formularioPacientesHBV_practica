<?php

namespace App\Models;

use CodeIgniter\Model;

class PacienteModel extends Model
{
    protected $table = 'pacientes';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'nombre',
        'apellido',
        'fecha_nacimiento',
        'genero',
        'tipo_documento',
        'numero_documento',
        'telefono',
        'email',
        'direccion',
        'tipo_sangre',
        'alergias',
        'historial_medico',
        'medicamentos',
        'contacto_emergencia_nombre',
        'contacto_emergencia_telefono',
        'contacto_emergencia_parentesco',
        'created_at',
        'updated_at'
    ];
    
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    protected $validationRules = [
        'nombre' => 'required|min_length[2]|max_length[100]',
        'apellido' => 'required|min_length[2]|max_length[100]',
        'fecha_nacimiento' => 'required|valid_date',
        'genero' => 'required|in_list[Masculino,Femenino,Otro]',
        'telefono' => 'required|min_length[8]|max_length[20]',
        'email' => 'permit_empty|valid_email',
        'numero_documento' => 'permit_empty|max_length[20]'
    ];
    
    protected $validationMessages = [
        'nombre' => [
            'required' => 'El nombre es obligatorio',
            'min_length' => 'El nombre debe tener al menos 2 caracteres'
        ],
        'apellido' => [
            'required' => 'El apellido es obligatorio',
            'min_length' => 'El apellido debe tener al menos 2 caracteres'
        ],
        'fecha_nacimiento' => [
            'required' => 'La fecha de nacimiento es obligatoria',
            'valid_date' => 'Ingrese una fecha válida'
        ],
        'genero' => [
            'required' => 'El género es obligatorio',
            'in_list' => 'Seleccione un género válido'
        ],
        'telefono' => [
            'required' => 'El teléfono es obligatorio',
            'min_length' => 'El teléfono debe tener al menos 8 dígitos'
        ],
        'email' => [
            'valid_email' => 'Ingrese un correo electrónico válido'
        ]
    ];
}