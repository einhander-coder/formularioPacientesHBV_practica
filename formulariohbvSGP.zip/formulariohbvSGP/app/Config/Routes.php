<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('pacientes', 'Pacientes::index');
$routes->get('pacientes/crear', 'Pacientes::crear');
$routes->post('pacientes/guardar', 'Pacientes::guardar');
$routes->get('pacientes/mostrar/(:num)', 'Pacientes::mostrar/$1');
$routes->get('pacientes/editar/(:num)', 'Pacientes::editar/$1');
$routes->post('pacientes/actualizar/(:num)', 'Pacientes::actualizar/$1');
$routes->get('pacientes/eliminar/(:num)', 'Pacientes::eliminar/$1');